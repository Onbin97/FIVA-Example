import json
import os

from datetime import datetime, timezone
from typing import Any, Optional, Union

from chalicelib.constants.common import DELETED, DEVICES, FREE, PAID, UPDATED_TIME_UTC
from chalicelib.slack_bot import post_slack_message


SERVER_ENV = os.getenv("SERVER_ENV")


def format_utc_timestamp(time_obj: datetime = None) -> str:
    if not time_obj:
        time_obj = datetime.now(timezone.utc)

    formatted_time = time_obj.strftime('%Y-%m-%d %I:%M:%S.') + time_obj.strftime('%f')[:3] + time_obj.strftime('%p')
    return formatted_time


def format_utc_timestamp_to_datetime(str_obj: str) -> datetime:
    try:
        formatted_time = datetime.strptime(str_obj, "%Y-%m-%d %I:%M:%S.%f%p")
    except ValueError:
        try:
            formatted_time = datetime.strptime(str_obj, "%Y-%m-%d %I:%M:%S%p")
        except ValueError:
            formatted_time = datetime.strptime(str_obj, "%Y-%m-%d %I.%M.%S%p")

    return formatted_time.replace(tzinfo=timezone.utc)


def format_utc_date_str() -> str:
    current_utc_time = datetime.now(timezone.utc)
    formatted_time = current_utc_time.strftime('%Y-%m-%d')
    return formatted_time


def create_change_log_data_set(
    ref_key: str, new_data: Union[str, int, bool, dict], old_data: Optional[Union[str, int, bool, dict]] = None
) -> dict:
    return {
        'EventName': f'{ref_key}Changed',
        'EventTimeUtc': format_utc_timestamp(),
        'OldData': old_data,
        'NewData': new_data,
    }


def create_event_bridge_schedule(
    client: Any,
    func_name: str,
    payload: dict,
    expression_time: datetime,
    group_name: str = 'default',
    name: str = '',
    timezone: str = 'Asia/Seoul',
) -> None:
    try:
        group_name = f'{group_name}-{SERVER_ENV}'
        response = client.list_schedule_groups(MaxResults=100)['ScheduleGroups']
        schedule_groups = [schedule_group.get('Name') for schedule_group in response]

        if group_name not in schedule_groups:
            client.create_schedule_group(Name=group_name)

        expression_time_str = f'at({expression_time.strftime("%Y-%m-%dT%H:%M:%S")})'
        client.create_schedule(
            FlexibleTimeWindow={'Mode': 'OFF'},
            ActionAfterCompletion='DELETE',
            GroupName=group_name,
            Name=name if name else datetime.now().strftime("%Y-%m-%dT%H-%M-%S.%f"),
            ScheduleExpression=expression_time_str,
            ScheduleExpressionTimezone=timezone,
            Target={
                'Arn': f'arn:aws:lambda:ap-northeast-2:\
{os.getenv("AWS_ACCOUNT_ID")}:function:fiva-api-server-{SERVER_ENV}-{func_name}',
                'Input': json.dumps(payload),
                'RoleArn': f'arn:aws:iam::{os.getenv("AWS_ACCOUNT_ID")}:role/EventBridgeScheduler-FCM',
                'RetryPolicy': {'MaximumEventAgeInSeconds': 60, 'MaximumRetryAttempts': 0},
            },
        )

    except Exception as e:
        post_slack_message(
            channel_id=os.getenv('SLACK_DEV_CHANNEL_ID'),
            token=os.getenv('SLACK_TOKEN_FCM'),
            text=f'예약에 실패한 메시지가 있습니다.\n\nExpression Time: {expression_time.strftime("%Y-%m-%dT%H:%M:%S")} \n\
Message Payload:\n```{payload}```',
        )
        print(e)


def update_event_bridge_schedule(
    client: Any, payload: dict, expression_time: datetime, name: str = None, timezone: str = 'Asia/Seoul'
) -> None:
    try:
        expression_time_str = f'at({expression_time.strftime("%Y-%m-%dT%H:%M:%S")})'
        client.update_schedule(
            FlexibleTimeWindow={'Mode': 'OFF'},
            ActionAfterCompletion='DELETE',
            Name=name if name else datetime.now().strftime("%Y-%m-%dT%H-%M-%S.%f"),
            ScheduleExpression=expression_time_str,
            ScheduleExpressionTimezone=timezone,
            Target={
                'Arn': f'arn:aws:lambda:ap-northeast-2:\
{os.getenv("AWS_ACCOUNT_ID")}:function:fiva-api-server-{os.getenv("SERVER_ENV")}-send_fcm_msg_func',
                'Input': json.dumps(payload),
                'RoleArn': f'arn:aws:iam::{os.getenv("AWS_ACCOUNT_ID")}:role/EventBridgeScheduler-FCM',
                'RetryPolicy': {'MaximumEventAgeInSeconds': 60, 'MaximumRetryAttempts': 0},
            },
        )

    except Exception as e:
        post_slack_message(
            channel_id=os.getenv('SLACK_DEV_CHANNEL_ID'),
            token=os.getenv('SLACK_TOKEN_FCM'),
            text=f'예약에 실패한 메시지가 있습니다.\n\nExpression Time: {expression_time.strftime("%Y-%m-%dT%H:%M:%S")} \n\
Message Payload:\n```{payload}```',
        )
        print(e)


def get_active_user_profile(user_key: str, user_data: dict[str, Any]) -> Optional[dict]:
    user_profile = user_data.get(user_key)

    if user_profile is None or user_profile.get(DELETED):
        return None
    return user_profile


def check_subscribing_user(user_key: str, user_profile: dict[str, Any]) -> bool:
    now = datetime.now(timezone.utc)

    if not user_profile:
        return False

    subscription = user_profile.get('Subscription')
    free_pass = user_profile.get('FreePassEndTimeUtc')

    if subscription and free_pass:
        if subscription.get('ExpireDate'):
            subscription_expire_date = format_utc_timestamp_to_datetime(subscription['ExpireDate'])
            if now <= subscription_expire_date:
                return PAID

        free_pass_expire_date = format_utc_timestamp_to_datetime(free_pass)
        if now <= free_pass_expire_date:
            return FREE

    if subscription and subscription.get('ExpireDate'):
        subscription_expire_date = format_utc_timestamp_to_datetime(subscription['ExpireDate'])

    if free_pass:
        if now <= format_utc_timestamp_to_datetime(free_pass):
            return FREE

    return False
