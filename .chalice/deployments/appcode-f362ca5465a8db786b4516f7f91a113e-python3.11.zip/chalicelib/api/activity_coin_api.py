import random

from typing import Any

from chalice import Blueprint
from chalice import BadRequestError
from chalice.app import Request, Response
from firebase_admin.db import Reference

from chalicelib.api_setup import APIHandler, common_set_up
from chalicelib.core import create_change_log_data_set, check_subscribing_user, format_utc_timestamp
from chalicelib.constants.common import ACTIVITY_COIN, COLLECTED_CURRENCY, DEFAULT_WORKOUT, EVENT_TIME_UTC, FREE, PAID
from chalicelib.constants.db_ref_key import (
    DB_ACTIVITY_COIN_LOGS_DATE_GROUPED,
    DB_BETA_USER_DATA,
    DB_BETA_USER_DATA_CHANGE_LOG,
    DB_BETA_USER_ITEM_DATA,
    DB_REWARD_DATA,
    DB_REWARD_LOGS,
    DB_METHODS_OF_ACTIVITY_COIN_ACQUISITION,
)


activity_coin_api_module = Blueprint(__name__)


class ActivityCoinAPIHandler:
    def __init__(self, root_ref: Reference, user_id: str, date_key: str, activity: str, count: int) -> None:
        self.root_ref = root_ref
        self.user_id = user_id
        self.date_key = date_key
        self.activity = activity
        self.count = count

        self.user_data_ref = root_ref.child(DB_BETA_USER_DATA)
        self.user_data = self.user_data_ref.get()
        self.user_profile = self.user_data[user_id]

        self.activity_coin_logs_date_grouped_ref = root_ref.child(DB_ACTIVITY_COIN_LOGS_DATE_GROUPED).child(
            self.date_key
        )

        self.sub = PAID if check_subscribing_user(user_key=self.user_id, user_data=self.user_data) else FREE
        self.methods_of_coin_acquisition = (
            self.root_ref.child(DB_METHODS_OF_ACTIVITY_COIN_ACQUISITION).child(self.sub).get()
        )

    def check_daily_max_coins(self):
        activity_coin_logs_date_grouped = self.activity_coin_logs_date_grouped_ref.get()
        if not activity_coin_logs_date_grouped or self.user_id not in activity_coin_logs_date_grouped:
            return False

        max_coins = self.methods_of_coin_acquisition[self.activity]['DailyMaxValue']
        user_daily_logs = activity_coin_logs_date_grouped[self.user_id]
        user_daily_activity_coins = sum(
            [
                daily_log['Coins']
                for daily_log in user_daily_logs.values()
                if isinstance(user_daily_logs, dict) and daily_log['Activity'] == self.activity
            ]
        )
        print(user_daily_activity_coins)
        if user_daily_activity_coins >= max_coins:
            return True
        return False

    def calculate_activity_coin_acquisition(self) -> dict[str, Any]:
        coins = (self.methods_of_coin_acquisition[self.activity]['ValuePer']) * self.count

        user_collected_currency = self.user_profile.get(COLLECTED_CURRENCY)

        if user_collected_currency:
            user_activity_coin = user_collected_currency.get(ACTIVITY_COIN) or 0
        else:
            user_activity_coin = 0

        activity_coin_data = {
            'Coins': coins,
            'BeforeCoins': user_activity_coin,
            'AfterCoins': (user_activity_coin + coins),
            'Activity': self.activity,
            EVENT_TIME_UTC: format_utc_timestamp(),
        }

        return activity_coin_data

    def update_user_activity_coins(self, activity_coin_data: dict):
        self.user_data_ref.child(self.user_id).child(COLLECTED_CURRENCY).update(
            {ACTIVITY_COIN: activity_coin_data['AfterCoins']}
        )
        self.activity_coin_logs_date_grouped_ref.child(self.user_id).push().set(activity_coin_data)
        return

    def transaction_log(self):
        return


@activity_coin_api_module.route('/activity-coin/acquisition', methods=['POST'])
@common_set_up(module=activity_coin_api_module)
def activity_acquisition_coin_api(request: Request, root_ref: Reference, handler: APIHandler) -> Response:
    user_id = request.query_params.get('UserId')
    if not user_id:
        raise BadRequestError('Missing user ID in the request')

    date_key = request.json_body.get('DateKey')
    if not date_key:
        raise BadRequestError('Missing date key in the request')

    activity = request.json_body.get('Activity')
    if not activity:
        raise BadRequestError('Missing category in the request')

    count = request.json_body.get('Count')
    if not count:
        raise BadRequestError('Missing count in the request')

    activity_coin_api_handler = ActivityCoinAPIHandler(
        root_ref=root_ref, user_id=user_id, date_key=date_key, activity=activity, count=count
    )

    if activity_coin_api_handler.check_daily_max_coins():
        return handler.response('max tokens', 201)

    result_data = activity_coin_api_handler.calculate_activity_coin_acquisition()
    activity_coin_api_handler.update_user_activity_coins(result_data)

    # reward_coins = methods_of_coin_acquisition[activity]

    # beta_user_change_log - 여긴 무조건 기존 코인량, 변화된 코인량
    # beta_user_coin_log - 여긴 무조건 기존 코인량, 변화된 코인량 획득, 소비
    # daily_user_coin_log
    # 모든 코인로그니깐 property 사용인지, 획득 매트릭 일

    # 하루 내가 최대인지아닌지를 어디서
    # user_dat
    # Acquisition or spend
    # 기존 코인량, 변화된 코인량
    #

    return handler.response('', 201)
