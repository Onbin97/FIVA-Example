import os
from datetime import datetime

from chalice import Blueprint
from chalice import BadRequestError
from chalice.app import Request, Response
from firebase_admin.db import Reference

from chalicelib.api_setup import APIHandler, common_set_up
from chalicelib.core import create_change_log_data_set
from chalicelib.constants.common import (
    FLOOR_KEY,
    FLOOR_USER_COUNT,
    FLOORS,
    MAP_KEY,
    PERCENTAGE,
    UPDATED_TIME_UTC,
    USER_LIST,
)
from chalicelib.constants.db_ref_key import (
    DB_BETA_USER_DATA,
    DB_BETA_USER_DATA_CHANGE_LOG,
    DB_BETA_USER_FLOOR_DATA,
    DB_STAIR_CLIMBING_MAP_DATA,
)
from chalicelib.db.engine import root_ref
from chalicelib.slack_bot import post_slack_message


stair_climbing_api_module = Blueprint(__name__)


# @live_schedule_fcm_module.schedule('cron(0 15 * * ? *)')
# def schedule_stair_climbing_data(event) -> None:
@stair_climbing_api_module.route('/stair-scheduling')
def schedule_stair_climbing_data() -> None:
    try:
        floor_data_to_update = {}

        user_floor_data = root_ref.child(DB_BETA_USER_FLOOR_DATA).get()
        total_climbing_user_count = len(user_floor_data)

        for user_key, data in user_floor_data.items():
            map_key = data[MAP_KEY]

            if map_key not in floor_data_to_update:
                floor_data_to_update[map_key] = {}

            floor = floor_data_to_update[map_key]
            if data[FLOOR_KEY] not in floor:
                floor[data[FLOOR_KEY]] = [{user_key: data[UPDATED_TIME_UTC]}]
            else:
                floor[data[FLOOR_KEY]].append({user_key: data[UPDATED_TIME_UTC]})

        stair_climbing_map_ref = root_ref.child(DB_STAIR_CLIMBING_MAP_DATA)
        stair_climbing_map = stair_climbing_map_ref.get()

        user_count = 0
        user_profile_data = root_ref.child(DB_BETA_USER_DATA).get()

        for map_key, floor_data in floor_data_to_update.items():
            sorted_floor_data = {data[0]: data[1] for data in sorted(floor_data.items(), reverse=True)}
            for floor, user_data_list in sorted_floor_data.items():
                current_floor_data = stair_climbing_map[map_key][FLOORS][floor]

                user_data_list.sort(
                    key=lambda x: datetime.strptime(list(x.values())[0], '%Y-%m-%d %I:%M:%S.%f%p'), reverse=True
                )
                floor_user_count = len(user_data_list)
                current_floor_data[FLOOR_USER_COUNT] = floor_user_count

                user_count += floor_user_count
                percentage = round(user_count / total_climbing_user_count, 3) if user_count else 0
                current_floor_data[PERCENTAGE] = percentage

                recent_user_data = {
                    list(recent_user.keys())[0]: user_profile_data[list(recent_user.keys())[0]]
                    for recent_user in user_data_list[:3]
                }
                current_floor_data[USER_LIST] = recent_user_data

        stair_climbing_map_ref.update(stair_climbing_map)

    except Exception as e:
        # post_slack_message(
        #     channel_id=os.getenv('SLACK_DEV_CHANNEL_ID'), token=os.getenv('SLACK_TOKEN_SERVER'), text='Climbing Stair Data Update Failed'
        # )
        print(e)


@stair_climbing_api_module.route('/stair', methods=['POST'])
@common_set_up(module=stair_climbing_api_module)
def climbing_stair_api(request: Request, root_ref: Reference, handler: APIHandler) -> Response:
    user_id = request.query_params.get('UserId')
    if not user_id:
        raise BadRequestError('Missing user ID in the request')

    stair_floor_info = request.json_body
    if not stair_floor_info:
        raise BadRequestError('Missing body in the request')

    stair_climbing_map_ref = root_ref.child(DB_STAIR_CLIMBING_MAP_DATA)
    stair_climbing_map = stair_climbing_map_ref.get()

    map_key = stair_floor_info.get(MAP_KEY)
    if map_key not in stair_climbing_map:
        raise BadRequestError('Invalid map key')

    floor_key = stair_floor_info.get(FLOOR_KEY) + 1

    if floor_key > len(stair_climbing_map[map_key][FLOORS]):
        raise BadRequestError('Invalid floor key')

    next_floor_info = {MAP_KEY: map_key, FLOOR_KEY: floor_key, UPDATED_TIME_UTC: handler.timestamp}

    root_ref.child(DB_BETA_USER_FLOOR_DATA).child(user_id).update(next_floor_info)
    root_ref.child(DB_BETA_USER_DATA_CHANGE_LOG).child(user_id).push().set(
        create_change_log_data_set(ref_key=FLOORS, new_data=next_floor_info)
    )

    return handler.response('', 201)
