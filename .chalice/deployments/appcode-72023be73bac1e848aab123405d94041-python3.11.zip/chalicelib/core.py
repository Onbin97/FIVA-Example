import os

from datetime import datetime, timezone
from typing import Optional, Union


def format_utc_timestamp() -> str:
    current_utc_time = datetime.now(timezone.utc)
    formatted_time = (
        current_utc_time.strftime('%Y-%m-%d %I:%M:%S.')
        + current_utc_time.strftime('%f')[:3]
        + current_utc_time.strftime('%p')
    )
    return formatted_time


def create_change_log_data_set(
    ref_key: str, old_data: Optional[Union[str, int, bool, dict]], new_data: Union[str, int, bool, dict]
) -> dict:
    return {
        'EventName': f'{ref_key}Changed',
        'EventTimeUtc': format_utc_timestamp(),
        'OldData': old_data,
        'NewData': new_data,
    }
