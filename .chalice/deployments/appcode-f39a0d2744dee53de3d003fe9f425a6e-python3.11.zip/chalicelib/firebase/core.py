import os
from typing import Optional

from firebase_admin import messaging


def send_fcm_to_topic(topic: str, title: str, body: str) -> str:
    message = messaging.Message(notification=messaging.Notification(title=title, body=body), topic=topic)
    response = messaging.send(message)
    return response
