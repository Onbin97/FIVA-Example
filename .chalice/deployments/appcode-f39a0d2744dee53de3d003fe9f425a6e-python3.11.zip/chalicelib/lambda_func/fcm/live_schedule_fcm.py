import boto3

from datetime import datetime, timedelta

from chalice import Blueprint

from chalicelib.core import create_event_bridge_schedule
from chalicelib.constants.common import LIVE_TITLE, PUSH_MESSAGE
from chalicelib.constants.db_ref_key import LIVE_SCHEDULE_INFO
from chalicelib.db.engine import root_ref
from chalicelib.firebase.core import send_fcm_to_topic


live_schedule_fcm_module = Blueprint(__name__)

AM = 'AM'
PM = 'PM'


# @live_schedule_fcm_module.schedule('cron(0 0 * * ? *)')
@live_schedule_fcm_module.route('/schedule', methods=['GET'])
def schedule_fcm_msg():
    try:
        live_schedule_ref = root_ref.child(LIVE_SCHEDULE_INFO)

        today = datetime.now()
        next_day = today + timedelta(days=1)

        this_month = today.strftime('%Y-%m')
        live_schedules = live_schedule_ref.get()

        fcm_data = {AM: {}, PM: {}}

        for value in live_schedules.values():
            for key, value in value.get(this_month).items():
                datetime_key = datetime.strptime(key, '%Y-%m-%d %I:%M%p')

                if datetime_key.date() == next_day.date():
                    if datetime_key.hour < 12:
                        fcm_data[AM][datetime_key] = {
                            LIVE_TITLE: value.get(LIVE_TITLE),
                            PUSH_MESSAGE: value.get(PUSH_MESSAGE),
                        }
                    else:
                        fcm_data[PM][datetime_key] = {
                            LIVE_TITLE: value.get(LIVE_TITLE),
                            PUSH_MESSAGE: value.get(PUSH_MESSAGE),
                        }

        client = boto3.client('scheduler')

        # {
        #     'AM': {
        #         datetime.datetime(2024, 8, 24, 7, 0): {
        #             'LiveTitle': '치얼스~! 🍻 마시면서 배우는 비어 요가',
        #             'PushMessage': None,
        #         },
        #         datetime.datetime(2024, 8, 24, 10, 0): {
        #             'LiveTitle': '치얼스~! 🍻 마시면서 배우는 비어 요가',
        #             'PushMessage': None,
        #         },
        #     },
        #     'PM': {
        #         datetime.datetime(2024, 8, 24, 20, 0): {
        #             'LiveTitle': '출렁이는🌊 팔뚝 살을 녹여주는 크로스핏',
        #             'PushMessage': None,
        #         },
        #         datetime.datetime(2024, 8, 24, 21, 0): {
        #             'LiveTitle': '출렁이는🌊 팔뚝 살을 녹여주는 크로스핏',
        #             'PushMessage': None,
        #         },
        #         datetime.datetime(2024, 8, 24, 22, 0): {'LiveTitle': '매끈 탄탄 팔다리🦵🏼 필라테스', 'PushMessage': None},
        #     },
        # }

        # if fcm_data.get(AM):
        # before_datetime = today.replace(hour=21, minute=40, second=0, microsecond=0)
        before_datetime = today.replace(hour=13, minute=40, second=0, microsecond=0)
        payload = {
            'title': '운동 시간!',
            'body': '출렁이는🌊 팔뚝 살을 녹여주는 크로스핏',
            'topic': 'test_schedule_240822_22',
        }
        create_event_bridge_schedule(client=client, payload=payload, expression_time=before_datetime)

        return {'msg': 'success'}

    except Exception as e:
        print(e)

    finally:
        client.close()


@live_schedule_fcm_module.lambda_function()
def send_fcm_msg(event, context):
    print(event)
    test_topic = event.get('topic')
    test_title = event.get('title')
    test_body = event.get('body')

    send_fcm_to_topic(topic=test_topic, title=test_title, body=test_body)

    return None
