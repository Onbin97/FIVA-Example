# beta_user_data
BETA_USER_DATA = 'beta_user_data'

# beta_user_data_change_log
BETA_USER_DATA_CHANGE_LOG = 'beta_user_data_change_log'

# beta_user_workout_logs'
BETA_USER_WORKOUT_LOGS = 'beta_user_workout_logs'

# content_info
CONTENT_INFO = 'content_info'
