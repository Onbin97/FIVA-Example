import os

from datetime import datetime

from firebase_admin import messaging


def create_fcm_datetime_topic(fcm_datetime: datetime) -> str:
    date_str = fcm_datetime.strftime('%y%m%d')
    time_str = fcm_datetime.strftime('%H')

    topic = (
        f'schedule_{date_str}_{time_str}'
        if os.getenv('SERVER_ENV') == 'prod'
        else f'test_schedule_{date_str}_{time_str}'
    )

    return topic


def send_fcm_to_topic(topic: str, title: str, body: str) -> None:
    message = messaging.Message(
        notification=messaging.Notification(title=title, body=body),
        apns=messaging.APNSConfig(
            payload=messaging.APNSPayload(aps=messaging.Aps(sound='default', content_available=True))
        ),
        topic=topic,
    )
    messaging.send(message)
