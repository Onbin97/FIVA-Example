# beta_user_data
DB_BETA_USER_DATA = 'beta_user_data'

# beta_user_data_change_log
DB_BETA_USER_DATA_CHANGE_LOG = 'beta_user_data_change_log'

# beta_user_event_data
DB_BETA_USER_EVENT_DATA = 'beta_user_event_data'

# beta_user_data_floor_data
DB_BETA_USER_FLOOR_DATA = 'beta_user_floor_data'

# beta_user_game_current_rank
DB_BETA_USER_GAME_CURRENT_WEEK_RANK = 'beta_user_game_current_week_rank'

# beta_user_game_logs
DB_BETA_USER_GAME_LOGS = 'beta_user_game_logs'

# beta_user_item_data
DB_BETA_USER_ITEM_DATA = 'beta_user_item_data'

# beta_user_workout_logs'
DB_BETA_USER_WORKOUT_LOGS = 'beta_user_workout_logs'

# content_info
DB_CONTENT_INFO = 'content_info'

# deleted_user_data
DB_DELETED_USER_DATA = 'deleted_user_data'

# game_ranking_current_week
DB_GAME_RANkING_CURRENT_WEEK = 'game_ranking_current_week'

# game_ranking_last_week
DB_GAME_RANkING_LAST_WEEK = 'game_ranking_last_week'

# reward_data
DB_REWARD_DATA = 'reward_data'

# reward_logs
DB_REWARD_LOGS = 'reward_logs'

# stair_climbing_map_data
DB_STAIR_CLIMBING_MAP_DATA = 'stair_climbing_map_data'

# workout_record_changes_date_grouped
DB_WORKOUT_RECORD_CHANGES_DATE_GROUPED = 'workout_record_changes_date_grouped'

# live_schedule_info
LIVE_SCHEDULE_INFO = 'live_schedule_info'
