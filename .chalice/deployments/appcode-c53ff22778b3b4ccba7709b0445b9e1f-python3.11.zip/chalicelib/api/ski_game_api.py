import os

from datetime import datetime, time, timedelta, timezone
from firebase_admin.db import Reference

from chalice import Blueprint, Rate
from chalice.app import Request, Response

from chalicelib.api_setup import APIHandler, common_set_up
from chalicelib.core import get_active_user_profile, format_utc_timestamp, format_utc_timestamp_to_datetime
from chalicelib.constants.common import (
    COSTUME_LIST,
    FULL,
    GAME_OVER_TIME_UTC,
    HALF,
    NICKNAME,
    RANK,
    SKI_GAME,
    UPDATED_TIME_UTC,
    USER_KEY,
    USER_LIST,
    WEEK_START_TIME_UTC,
)
from chalicelib.constants.db_ref_key import (
    DB_BETA_USER_DATA,
    DB_BETA_USER_GAME_CURRENT_WEEK_RANK,
    DB_BETA_USER_GAME_LOGS,
    DB_GAME_RANkING_CURRENT_WEEK,
    DB_GAME_RANkING_LAST_WEEK,
)
from chalicelib.db.engine import root_ref
from chalicelib.slack_bot import post_slack_message


ski_game_api_module = Blueprint(__name__)


class SkiGameHandler:
    def __init__(self) -> None:
        self.today = datetime.now()
        self.today_utc = datetime.now(tz=timezone.utc)
        self.weekday = datetime.combine(self.today.date(), time.min, tzinfo=timezone.utc) - timedelta(
            days=((self.today.weekday()) % 7), hours=9
        )
        self.user_data = root_ref.child(DB_BETA_USER_DATA).get()

        self.game_logs_ref = root_ref.child(DB_BETA_USER_GAME_LOGS)
        self.ski_game_current_week_ranking_ref = root_ref.child(DB_GAME_RANkING_CURRENT_WEEK).child(SKI_GAME)

    def calculate_current_week_rank(self):
        current_week_ranking_data = self.ski_game_current_week_ranking_ref.get()

        if current_week_ranking_data and self.weekday - format_utc_timestamp_to_datetime(
            current_week_ranking_data[WEEK_START_TIME_UTC]
        ) >= timedelta(days=7):
            self._update_last_week_ranking_data(current_week_ranking_data=current_week_ranking_data)

        ranking_data = {
            WEEK_START_TIME_UTC: format_utc_timestamp(self.weekday),
            UPDATED_TIME_UTC: format_utc_timestamp(self.today_utc),
        }
        game_logs = self.game_logs_ref.get()
        if not game_logs:
            return ranking_data

        ski_game_logs = {
            user_key: game_log[SKI_GAME] for user_key, game_log in game_logs.items() if game_log.get(SKI_GAME)
        }

        high_score_data = []
        for user_key, ski_game_log in ski_game_logs.items():
            if not get_active_user_profile(user_key, self.user_data):
                continue

            # Filter game logs for the current week
            weekly_logs = [
                log
                for log in ski_game_log.values()
                if isinstance(log, dict) and format_utc_timestamp_to_datetime(log[GAME_OVER_TIME_UTC]) >= self.weekday
            ]

            if not weekly_logs:
                continue

            # Find the log with the highest score in the current week
            # In case of a tie, choose the most recent one
            high_score_log = max(
                weekly_logs,
                key=lambda log: (
                    log[FULL] + (log[HALF] * 0.5),
                    format_utc_timestamp_to_datetime(log[GAME_OVER_TIME_UTC]),
                ),
            )

            high_score_log[USER_KEY] = user_key
            high_score_log[NICKNAME] = self.user_data[user_key].get(NICKNAME)
            high_score_log[COSTUME_LIST] = self.user_data[user_key].get(COSTUME_LIST)
            high_score_data.append(high_score_log)

        # Sort high score data: first by score in descending order, then by timestamp in ascending order (oldest first)
        high_score_data.sort(
            key=lambda x: (-(x[FULL] + (x[HALF] * 0.5)), format_utc_timestamp_to_datetime(x[GAME_OVER_TIME_UTC]))
        )
        for index, log in enumerate(high_score_data):
            log[RANK] = index + 1

        ranking_data[USER_LIST] = high_score_data
        self._update_current_week_ranking_data(ranking_data)

        user_rank_data = {log.pop(USER_KEY): {SKI_GAME: log} for log in high_score_data}
        self._update_current_week_user_ranking_data(user_rank_data)

    def _update_current_week_ranking_data(self, ranking_data: dict) -> None:
        self.ski_game_current_week_ranking_ref.update(ranking_data)

    def _update_current_week_user_ranking_data(self, user_rank_data: dict) -> None:
        root_ref.child(DB_BETA_USER_GAME_CURRENT_WEEK_RANK).update(user_rank_data)

    def _update_last_week_ranking_data(self, current_week_ranking_data: dict) -> None:
        current_week_ranking_data[UPDATED_TIME_UTC] = format_utc_timestamp(self.today_utc)

        root_ref.child(DB_GAME_RANkING_LAST_WEEK).child(SKI_GAME).update(
            {current_week_ranking_data[WEEK_START_TIME_UTC]: current_week_ranking_data}
        )


@ski_game_api_module.route('/games/ski', methods=['PUT'])
@common_set_up(module=ski_game_api_module)
def ski_game_rank_api(request: Request, root_ref: Reference, handler: APIHandler) -> Response:
    SkiGameHandler().calculate_current_week_rank()

    return handler.response('', 200)


@ski_game_api_module.schedule(Rate(5, Rate.MINUTES))
def schedule_ski_game_rank(event) -> None:
    try:
        SkiGameHandler().calculate_current_week_rank()

    except Exception as e:
        post_slack_message(
            channel_id=os.getenv('SLACK_DEV_CHANNEL_ID'),
            token=os.getenv('SLACK_TOKEN_SERVER'),
            text=f'Ski-Game Ranking Data Update Failed 🚨\n\nError Message:\n```ERROR: {e}```',
        )
        print(e)
