# beta_user_data
DB_BETA_USER_DATA = 'beta_user_data'

# beta_user_data_change_log
DB_BETA_USER_DATA_CHANGE_LOG = 'beta_user_data_change_log'

# beta_user_workout_logs'
DB_BETA_USER_WORKOUT_LOGS = 'beta_user_workout_logs'

# content_info
DB_CONTENT_INFO = 'content_info'

# workout_record_changes_date_grouped
DB_WORKOUT_RECORD_CHANGES_DATE_GROUPED = 'workout_record_changes_date_grouped'
