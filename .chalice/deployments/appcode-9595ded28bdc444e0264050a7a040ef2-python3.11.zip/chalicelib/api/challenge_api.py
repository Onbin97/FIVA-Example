from datetime import datetime

from chalice import Blueprint
from chalice import BadRequestError
from chalice.app import Request, Response
from firebase_admin.db import Reference

from chalicelib.api_setup import APIHandler, common_set_up
from chalicelib.constants.common import DURATION_SEC, END_TIME_UTC, START_TIME_UTC
from chalicelib.constants.db_ref_key import (
    DB_BETA_USER_EVENT_DATA,
    DB_BETA_USER_CHALLENGE_SUCCEEDED_DATA,
    DB_WORKOUT_RECORD_CHANGES_USER_DATE_GROUPED,
    DB_INAPP_CHALLENGE_BATCH_DATA,
)
from chalicelib.core import async_fetch_paths, format_kst_timestamp_to_datetime


challenge_api_module = Blueprint(__name__)


@challenge_api_module.route('/challenge/overall-status', methods=['GET'])
@common_set_up(module=challenge_api_module)
def challenge_overall_status_api(request: Request, root_ref: Reference, handler: APIHandler) -> Response:
    user_id = request.query_params.get('UserId')
    if not user_id:
        raise BadRequestError('Missing user ID in the request')
    year = request.query_params.get('Year')

    now = datetime.now()

    if not year:
        year = str(now.year)
    else:
        year = str(year)

    path_list = [DB_BETA_USER_EVENT_DATA, DB_BETA_USER_CHALLENGE_SUCCEEDED_DATA, DB_INAPP_CHALLENGE_BATCH_DATA]
    data = async_fetch_paths(root_ref, path_list)

    user_event_data = data[DB_BETA_USER_EVENT_DATA]
    inapp_challenge_data = data[DB_INAPP_CHALLENGE_BATCH_DATA]
    user_challenge_succeeded_data = data[DB_BETA_USER_CHALLENGE_SUCCEEDED_DATA]  # User List

    result = {
        challenge_key: {START_TIME_UTC: data[START_TIME_UTC], END_TIME_UTC: data[END_TIME_UTC]}
        for challenge_key, data in inapp_challenge_data.items()
        if year in challenge_key
    }

    def check_user_challenge_participation(challenge_key, user_id):
        user_list = user_event_data.get(challenge_key)
        if user_list and isinstance(user_list, list) and user_id in user_list:
            return True
        return False

    def check_user_challenge_succeeded(challenge_key, user_id):
        user_list = user_challenge_succeeded_data.get(challenge_key)
        if user_list and isinstance(user_list, list) and user_id in user_list:
            return True
        return False

    result = {}
    for challenge_key, challenge_data in inapp_challenge_data.items():
        if year in challenge_key:
            start_time_str = challenge_data[START_TIME_UTC]
            end_time_str = challenge_data[END_TIME_UTC]

            start_time = format_kst_timestamp_to_datetime(start_time_str)
            end_time = format_kst_timestamp_to_datetime(end_time_str)

            application_start_time = format_kst_timestamp_to_datetime(challenge_data['ApplicationStartTimeUtc'])
            application_due_time = format_kst_timestamp_to_datetime(challenge_data['ApplicationDueTimeUtc'])

            if start_time > now:
                challenge_status = 'Applying' if application_start_time <= now < application_due_time else 'NotStarted'
            elif end_time < now:
                if not check_user_challenge_participation(challenge_key, user_id):
                    challenge_status = 'NotParticipated'
                else:
                    challenge_status = 'Succeed' if check_user_challenge_succeeded(challenge_key, user_id) else 'Failed'
            elif start_time <= now < end_time:
                challenge_status = (
                    'Participating' if check_user_challenge_participation(challenge_key, user_id) else 'NotParticipated'
                )
            result[challenge_key] = {
                'Status': challenge_status,
                'Month': challenge_data.get('Month'),
                'StartDate': start_time_str,
                'EndDate': end_time_str,
            }

    return handler.response(result, 200)


@challenge_api_module.route('/challenge/user-record', methods=['POST'])
@common_set_up(module=challenge_api_module)
def challenge_user_record_api(request: Request, root_ref: Reference, handler: APIHandler) -> Response:
    user_id = request.query_params.get('UserId')
    if not user_id:
        raise BadRequestError('Missing user ID in the request')

    body = request.json_body
    if not body:
        raise BadRequestError('Missing body in the request')

    challenge_batch_list = body.get('BatchKeys')
    if not challenge_batch_list:
        raise BadRequestError('Missing challenge batch keys in the request')

    path_list = [f'{DB_WORKOUT_RECORD_CHANGES_USER_DATE_GROUPED}/{user_id}', DB_INAPP_CHALLENGE_BATCH_DATA]
    data = async_fetch_paths(root_ref, path_list)

    user_workout_record_changes_date_grouped = data[f'{DB_WORKOUT_RECORD_CHANGES_USER_DATE_GROUPED}/{user_id}']
    inapp_challenge_data = data[DB_INAPP_CHALLENGE_BATCH_DATA]

    result = {}
    for challenge_batch_key in challenge_batch_list:
        records = {'Records': {}}
        if not user_workout_record_changes_date_grouped:
            records[challenge_batch_key] = records

        challenge_data = inapp_challenge_data[challenge_batch_key]
        records['Threshold'] = challenge_data['Threshold']

        start_time_str = challenge_data[START_TIME_UTC]
        end_time_str = challenge_data[END_TIME_UTC]

        start_time = format_kst_timestamp_to_datetime(start_time_str)
        end_time = format_kst_timestamp_to_datetime(end_time_str)

        start_date = datetime(start_time.year, start_time.month, start_time.day)
        end_date = datetime(end_time.year, end_time.month, end_time.day)

        for date_key, workout_data in user_workout_record_changes_date_grouped.items():
            workout_date = datetime.strptime(date_key, '%Y-%m-%d')
            if start_date <= workout_date <= end_date:
                total_duration = sum(value[DURATION_SEC] for value in workout_data.values())
                records['Records'][date_key] = {DURATION_SEC: total_duration}

        result[challenge_batch_key] = records

    return handler.response(result, 200)
