import random

from typing import Any

from chalice import Blueprint
from chalice import BadRequestError
from chalice.app import Request, Response
from firebase_admin.db import Reference

from chalicelib.api_setup import APIHandler, common_set_up
from chalicelib.core import check_subscribing_user, format_utc_timestamp
from chalicelib.constants.common import (
    ACTIVITY,
    ACTIVITY_COIN,
    COINS,
    COLLECTED_CURRENCY,
    DATE_KEY,
    EVENT_TIME_UTC,
    FREE,
)
from chalicelib.constants.db_ref_key import (
    DB_ACTIVITY_COIN_LOGS_DATE_GROUPED,
    DB_BETA_USER_ACTIVITY_COIN_LOGS,
    DB_BETA_USER_DATA,
    DB_METHODS_OF_ACTIVITY_COIN_ACQUISITION,
)


activity_coin_api_module = Blueprint(__name__)

ACQUISITION_STATUS = 'AcquisitionStatus'


class ActivityCoinAPIHandler:
    def __init__(self, root_ref: Reference, user_id: str, activity: str) -> None:
        self.acquisition_status = {ACQUISITION_STATUS: f'{activity}Enable'}
        self.root_ref = root_ref
        self.user_id = user_id
        self.activity = activity

        self.user_data_ref = root_ref.child(DB_BETA_USER_DATA)
        self.user_activity_coin_logs_ref = root_ref.child(DB_BETA_USER_ACTIVITY_COIN_LOGS).child(user_id)

    def update_user_activity_coins(self, coins):
        activity_coin_data = {}

        def transaction_update(current_data):
            if current_data is None:
                current_data = 0

            if current_data + coins < 0:
                raise BadRequestError('Not enough coins')

            activity_coin_data.update(
                {
                    COINS: coins,
                    'BeforeCoins': current_data,
                    'AfterCoins': (current_data + coins),
                    ACTIVITY: self.activity,
                    EVENT_TIME_UTC: format_utc_timestamp(),
                    **self.acquisition_status,
                }
            )
            return current_data + coins

        result = (
            self.user_data_ref.child(self.user_id)
            .child(COLLECTED_CURRENCY)
            .child(ACTIVITY_COIN)
            .transaction(transaction_update)
        )

        if result is not None:
            self.logging_activity_coin_data(activity_coin_data=activity_coin_data)
            return activity_coin_data

    def logging_activity_coin_data(self, activity_coin_data):
        self.user_activity_coin_logs_ref.push().set(activity_coin_data)


class ActivityCoinAcquisitionHandler(ActivityCoinAPIHandler):
    def __init__(self, root_ref: Reference, user_id: str, date_key: str, activity: str, count: int) -> None:
        super().__init__(root_ref, user_id, activity)

        self.count = count
        self.date_key = date_key
        self.user_profile = self.root_ref.child(DB_BETA_USER_DATA).child(self.user_id).get()
        self.sub = check_subscribing_user(user_key=user_id, user_profile=self.user_profile) or FREE
        self.methods_of_coin_acquisition = (
            self.root_ref.child(DB_METHODS_OF_ACTIVITY_COIN_ACQUISITION).child(self.sub).get()
        )
        self.activity_coin_logs_date_grouped_ref = root_ref.child(DB_ACTIVITY_COIN_LOGS_DATE_GROUPED).child(
            self.date_key
        )

    def get_remaining_coins(self) -> bool:
        activity_coin_logs_date_grouped = self.activity_coin_logs_date_grouped_ref.get()
        max_coins = self.methods_of_coin_acquisition[self.activity]['DailyMaxValue']

        if not activity_coin_logs_date_grouped or self.user_id not in activity_coin_logs_date_grouped:
            return max_coins

        user_daily_logs = activity_coin_logs_date_grouped[self.user_id]
        user_daily_activity_coins = sum(
            [
                daily_log[COINS]
                for daily_log in user_daily_logs.values()
                if isinstance(daily_log, dict) and daily_log[ACTIVITY] == self.activity
            ]
        )

        if user_daily_activity_coins >= max_coins:
            return 0
        return max_coins - user_daily_activity_coins

    def calculate_coins(self, remaining_coins) -> int:
        if self.activity not in self.methods_of_coin_acquisition:
            raise BadRequestError('Invalid activity')
        coins = self.methods_of_coin_acquisition[self.activity]['ValuePer'] * self.count
        if remaining_coins <= coins:
            self.acquisition_status[ACQUISITION_STATUS] = f'{self.activity}Disable'
            return remaining_coins
        return coins

    def logging_activity_coin_acquisition_date_grouped_data(self, activity_coin_data):
        self.activity_coin_logs_date_grouped_ref.child(self.user_id).push().set(activity_coin_data)


class ActivityCoinConsumptionHandler(ActivityCoinAPIHandler):
    def __init__(self, root_ref: Reference, user_id: str, activity: str, coins: int) -> None:
        super().__init__(root_ref, user_id, activity)
        self.coins = -coins


@activity_coin_api_module.route('/activity-coin/acquisition', methods=['POST', ''])
@common_set_up(module=activity_coin_api_module)
def activity_coin_acquisition_api(request: Request, root_ref: Reference, handler: APIHandler) -> Response:
    user_id = request.query_params.get('UserId')
    if not user_id:
        raise BadRequestError('Missing user ID in the request')

    date_key = request.json_body.get(DATE_KEY)
    if not date_key:
        raise BadRequestError('Missing date key in the request')

    activity = request.json_body.get(ACTIVITY)
    if not activity:
        raise BadRequestError('Missing category in the request')

    count = request.json_body.get('Count')
    if not count:
        raise BadRequestError('Missing count in the request')

    activity_coin_api_handler = ActivityCoinAcquisitionHandler(
        root_ref=root_ref, user_id=user_id, activity=activity, count=count, date_key=date_key
    )

    remaining_coins = activity_coin_api_handler.get_remaining_coins()
    if not remaining_coins:
        return handler.response(
            {COINS: 0, ACQUISITION_STATUS: f'{activity}Disable', EVENT_TIME_UTC: handler.timestamp}, 201
        )

    result = activity_coin_api_handler.update_user_activity_coins(
        coins=activity_coin_api_handler.calculate_coins(remaining_coins=remaining_coins)
    )
    if result:
        activity_coin_api_handler.logging_activity_coin_acquisition_date_grouped_data(result)

    return handler.response(result, 201)


@activity_coin_api_module.route('/activity-coin/consumption', methods=['POST'])
@common_set_up(module=activity_coin_api_module)
def activity_coin_consumption_api(request: Request, root_ref: Reference, handler: APIHandler) -> Response:
    user_id = request.query_params.get('UserId')
    if not user_id:
        raise BadRequestError('Missing user ID in the request')

    activity = request.json_body.get(ACTIVITY)
    if not activity:
        raise BadRequestError('Missing category in the request')

    coins = request.json_body.get(COINS)
    if not coins:
        raise BadRequestError('Missing count in the request')

    activity_coin_api_handler = ActivityCoinConsumptionHandler(
        root_ref=root_ref, user_id=user_id, activity=activity, coins=coins
    )

    result = activity_coin_api_handler.update_user_activity_coins(coins=activity_coin_api_handler.coins)

    return handler.response(result, 201)
