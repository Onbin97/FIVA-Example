EVENT_TIME_UTC = 'EventTimeUtc'
DURATION_SEC = 'DurationSec'

# ref
CALCULATED_LOGS = 'CalculatedLogs'
CLASS_INFO = 'ClassInfo'
DATETIME_KEY = 'DatetimeKey'
JOIN_COUNT = 'JoinCount'
KCAL = 'Kcal'
LOGS = 'Logs'
PROCESS_CHECKED = 'ProcessChecked'
TOTAL_WORKOUT_TIME = 'TotalWorkoutTime'
TOTAL_CALROIES_BURNED = 'TotalCalroiesBurned'
