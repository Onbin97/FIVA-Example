# beta_user_data
BETA_USER_DATA = 'beta_user_data'

# beta_user_data_change_log
BETA_USER_DATA_CHANGE_LOG = 'beta_user_data_change_log'

# beta_user_health_data
BETA_USER_HEALTH_DATA = 'beta_user_health_data'
