import os
import requests

from datetime import datetime

from chalice import Blueprint

from chalicelib.db.engine import root_ref
from chalicelib.constants.common import (
    BIRTHDAY,
    CHALLENGE,
    FLOOR_KEY,
    HEIGHT,
    MAP_KEY,
    JOIN_COUNT,
    NICKNAME,
    PHONE_NUMBER,
    TOTAL_CALROIES_BURNED,
    TOTAL_WORKOUT_TIME,
    WEIGHT,
)
from chalicelib.constants.db_ref_key import (
    DB_BETA_USER_DATA,
    DB_DELETED_USER_DATA,
    DB_BETA_USER_EVENT_DATA,
    DB_BETA_USER_FLOOR_DATA,
)


mixpanel_migration_module = Blueprint(__name__)


PROJECT_TOKEN = os.getenv('MIXPANEL_PROJECT_TOKEN')

BMI = 'BMI'

user_data = root_ref.child(DB_BETA_USER_DATA).get()
deleted_user_data = root_ref.child(DB_DELETED_USER_DATA).get()
challenge_data = root_ref.child(DB_BETA_USER_EVENT_DATA).get()
user_floor_data = root_ref.child(DB_BETA_USER_FLOOR_DATA).get()


def flush(payload):
    url = "https://api.mixpanel.com/engage#profile-batch-update"
    headers = {"accept": "text/plain", "content-type": "application/json"}

    response = requests.post(url, json=payload, headers=headers)

    print(response.text)
    return response.text


def reformat_birthdate(date_str):
    if len(date_str) != 6 or not date_str.isdigit():
        return None

    year = int(date_str[:2])
    month = date_str[2:4]
    day = date_str[4:6]

    current_year = datetime.now().year % 100
    if year <= current_year:
        full_year = 2000 + year
    else:
        full_year = 1900 + year

    return f"{full_year}-{month}-{day}"


@mixpanel_migration_module.schedule('cron(5 15 * * ? *)')
def schedule_user_profile_migration(event) -> None:
    sent_count = 0
    payload = []

    for user_id, user_info in user_data.items():
        if user_info.get('Deleted'):
            user_info = deleted_user_data.get(user_id)
            if not user_info:
                continue

        user_height = user_info.get(HEIGHT)
        user_weight = user_info.get(WEIGHT)

        user_bmi = (
            round(user_weight / ((user_height / 100) * (user_height / 100)), 1) if user_height and user_weight else 0
        )

        data = {
            '$token': PROJECT_TOKEN,
            '$distinct_id': user_id,
            '$set': {
                '$name': user_id,
                HEIGHT: user_height,
                WEIGHT: user_weight,
                NICKNAME: user_info.get(NICKNAME),
                BMI: user_bmi,
                PHONE_NUMBER: user_info.get(PHONE_NUMBER),
                JOIN_COUNT: user_info.get(JOIN_COUNT) or 0,
                TOTAL_WORKOUT_TIME: user_info.get(TOTAL_WORKOUT_TIME) or 0,
                TOTAL_CALROIES_BURNED: user_info.get(TOTAL_CALROIES_BURNED) or 0,
                BIRTHDAY: reformat_birthdate(user_info.get(BIRTHDAY, '')),
            },
        }

        if user_id in user_floor_data:
            data['$set'][MAP_KEY] = user_floor_data[user_id].get(MAP_KEY)
            data['$set'][FLOOR_KEY] = user_floor_data[user_id].get(FLOOR_KEY) + 1

        for challenge_key, user_list in challenge_data.items():
            if user_id in user_list:
                data['$set'][f'{CHALLENGE}_{challenge_key[-1]}'] = 'True'

        payload.append(data)

        if len(payload) >= 500:
            flush(payload=payload)

            sent_count += 1
            payload = []
            print(sent_count)

    if payload:
        flush(payload=payload)
        sent_count += 1
        print(sent_count)
