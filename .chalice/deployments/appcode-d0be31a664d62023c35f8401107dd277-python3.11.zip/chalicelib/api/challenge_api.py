import asyncio

from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from typing import Optional

from chalice import Blueprint
from chalice import BadRequestError
from chalice.app import Request, Response
from firebase_admin.db import Reference

from chalicelib.api_setup import APIHandler, common_set_up
from chalicelib.constants.common import (
    ACTIVITY,
    ACTIVITY_COIN,
    COINS,
    COLLECTED_CURRENCY,
    DATE_KEY,
    END_TIME_UTC,
    EVENT_TIME_UTC,
    FREE,
    PAID,
    START_TIME_UTC,
)
from chalicelib.constants.db_ref_key import (
    DB_BETA_USER_EVENT_DATA,
    DB_BETA_USER_GAME_LOGS,
    DB_BETA_USER_WORKOUT_LOGS,
    DB_INAPP_CHALLENGE_BATCH_DATA,
)
from chalicelib.core import async_fetch_paths, format_kst_timestamp_to_datetime


challenge_api_module = Blueprint(__name__)


@challenge_api_module.route('/challenge/overall-status', methods=['GET'])
@common_set_up(module=challenge_api_module)
def challenge_overall_status_api(request: Request, root_ref: Reference, handler: APIHandler) -> Response:
    user_id = request.query_params.get('UserId')
    if not user_id:
        raise BadRequestError('Missing user ID in the request')
    year = request.query_params.get('Year')

    now = datetime.now()
    # # TODO: Delete test Now
    # now = datetime(2024, 12, 21, 15, 0)

    if not year:
        year = str(now.year)
    else:
        year = str(year)

    path_list = [DB_BETA_USER_EVENT_DATA, DB_INAPP_CHALLENGE_BATCH_DATA]
    data = async_fetch_paths(root_ref, path_list)

    user_event_data = data[DB_BETA_USER_EVENT_DATA]
    inapp_challenge_data = data[DB_INAPP_CHALLENGE_BATCH_DATA]
    user_challenge_succeeded_data = {'batch_key': []}  # User List

    print(year)
    result = {
        challenge_key: {START_TIME_UTC: data[START_TIME_UTC], END_TIME_UTC: data[END_TIME_UTC]}
        for challenge_key, data in inapp_challenge_data.items()
        if year in challenge_key
    }

    def check_user_challenge_participation(challenge_key, user_id):
        user_list = user_event_data.get(challenge_key)
        if user_list and isinstance(user_list, list) and user_id in user_list:
            return True
        return False

    def check_user_challenge_succeeded(challenge_key, user_id):
        # TODO: Get UserList
        user_list = ['ox36mC5g3nN4RScJBGYirPPAbVa2']
        if user_list and isinstance(user_list, list) and user_id in user_list:
            return True
        return False

    result = {}
    for challenge_key, data in inapp_challenge_data.items():
        if year in challenge_key:
            start_time_str = data[START_TIME_UTC]
            end_time_str = data[END_TIME_UTC]

            start_time = format_kst_timestamp_to_datetime(start_time_str)
            end_time = format_kst_timestamp_to_datetime(end_time_str)

            application_start_time = format_kst_timestamp_to_datetime(data['ApplicationStartTimeUtc'])
            application_due_time = format_kst_timestamp_to_datetime(data['ApplicationDueTimeUtc'])

            if start_time > now:
                challenge_status = 'Applying' if application_start_time <= now < application_due_time else 'NotStarted'
            elif end_time < now:
                if not check_user_challenge_participation(challenge_key, user_id):
                    challenge_status = 'NotParticipated'
                else:
                    challenge_status = 'Succeed' if check_user_challenge_succeeded(challenge_key, user_id) else 'Failed'
            elif start_time <= now < end_time:
                challenge_status = (
                    'Participating' if check_user_challenge_participation(challenge_key, user_id) else 'NotParticipated'
                )
            result[challenge_key] = {
                'Status': challenge_status,
                'Month': data.get('Month'),
                'StartDate': start_time_str,
                'EndDate': end_time_str,
            }

    return handler.response(result, 200)


@challenge_api_module.route('/challenge/user-record', methods=['POST'])
@common_set_up(module=challenge_api_module)
def challenge_user_record_api(request: Request, root_ref: Reference, handler: APIHandler) -> Response:
    user_id = request.query_params.get('UserId')
    if not user_id:
        raise BadRequestError('Missing user ID in the request')

    challenge_batch_list = request.json_body
    if not challenge_batch_list:
        raise BadRequestError('Missing body in the request')

    path_list = [
        f"{DB_BETA_USER_WORKOUT_LOGS}/{user_id}",
        f"{DB_BETA_USER_GAME_LOGS}/{user_id}",
        DB_INAPP_CHALLENGE_BATCH_DATA,
    ]

    # for challenge_batch_key in challenge_batch_list:

    return handler.response({}, 200)
