import json
import os

from datetime import datetime, timezone
from typing import Any, Optional, Union

from chalicelib.slack_bot import post_slack_message


def format_utc_timestamp(time_obj: datetime = None) -> str:
    if not time_obj:
        time_obj = datetime.now(timezone.utc)

    formatted_time = time_obj.strftime('%Y-%m-%d %I:%M:%S.') + time_obj.strftime('%f')[:3] + time_obj.strftime('%p')
    return formatted_time


def format_utc_date_str() -> str:
    current_utc_time = datetime.now(timezone.utc)
    formatted_time = current_utc_time.strftime('%Y-%m-%d')
    return formatted_time


def create_change_log_data_set(
    ref_key: str, new_data: Union[str, int, bool, dict], old_data: Optional[Union[str, int, bool, dict]] = None
) -> dict:
    return {
        'EventName': f'{ref_key}Changed',
        'EventTimeUtc': format_utc_timestamp(),
        'OldData': old_data,
        'NewData': new_data,
    }


def create_event_bridge_schedule(
    client: Any, payload: dict, expression_time: datetime, name: str = None, timezone: str = 'Asia/Seoul'
) -> None:
    try:
        expression_time_str = f'at({expression_time.strftime("%Y-%m-%dT%H:%M:%S")})'

        client.create_schedule(
            FlexibleTimeWindow={'Mode': 'OFF'},
            ActionAfterCompletion='DELETE',
            Name=name if name else datetime.now().strftime("%Y-%m-%dT%H-%M-%S.%f"),
            ScheduleExpression=expression_time_str,
            ScheduleExpressionTimezone=timezone,
            Target={
                'Arn': f'arn:aws:lambda:ap-northeast-2:\
{os.getenv("AWS_ACCOUNT_ID")}:function:fiva-api-server-{os.getenv("SERVER_ENV")}-send_fcm_msg',
                'Input': json.dumps(payload),
                'RoleArn': f'arn:aws:iam::{os.getenv("AWS_ACCOUNT_ID")}:role/EventBridgeScheduler-FCM',
                'RetryPolicy': {'MaximumEventAgeInSeconds': 60, 'MaximumRetryAttempts': 0},
            },
        )

    except Exception as e:
        post_slack_message(
            channel_id=os.getenv('SLACK_DEV_CHANNEL_ID'),
            token=os.getenv('SLACK_TOKEN_FCM'),
            text=f'예약에 실패한 메시지가 있습니다.\n\nExpression Time: {expression_time.strftime("%Y-%m-%dT%H:%M:%S")} \n\
Message Payload:\n```{payload}```',
        )
        print(e)
