import os
import random

from itertools import chain

from chalice import Blueprint, CORSConfig
from chalice import BadRequestError
from chalice.app import Request, Response
from firebase_admin.db import Reference

from chalicelib.api_setup import APIHandler, common_set_up
from chalicelib.constants.common import (
    CHAT,
    CHATTING,
    DELETED,
    DEVICES,
    GROUP_KEY,
    GROUP_NAME,
    MY_GROUP_LIST,
    NICKNAME,
    TOKEN,
    WORKOUT,
)
from chalicelib.constants.db_ref_key import (
    DB_BETA_GROUP_LOGGING,
    DB_BETA_USER_DATA_CHANGE_LOG,
    DB_BETA_GROUP_INFO,
    DB_BETA_GROUP_MEMBER,
    DB_BETA_GROUP_MEMBER_TOKENS,
    DB_BETA_USER_DATA,
)
from chalicelib.firebase.core import send_fcm_multicast


groups_api_module = Blueprint(__name__)

HOST = 'group'
WORKOUT_PATH = '/lounge'
CHATTING_PATH = '/lounge/chatting'

cors_config = CORSConfig(allow_origin=os.getenv('DUX_GROUP_CHAT_URL'))

DUX_GROUP_KEY = 'DuxGroup'


@groups_api_module.route('/groups/chat-alert', methods=['POST'], cors=cors_config)
@common_set_up(module=groups_api_module)
def lounge_chat_alert_api(request: Request, root_ref: Reference, handler: APIHandler) -> Response:
    user_id = request.query_params.get('UserId')
    if not user_id:
        raise BadRequestError('Missing user ID in the request')

    chat = request.json_body.get(CHAT)
    if not chat:
        raise BadRequestError('Missing chat-text in the request')

    group_key = request.query_params.get(GROUP_KEY)
    if group_key == DUX_GROUP_KEY:
        return handler.response('', 201)

    group_member_tokens = root_ref.child(DB_BETA_GROUP_MEMBER_TOKENS).child(group_key).get()

    if group_member_tokens and group_member_tokens.get(CHATTING):
        user_info = root_ref.child(DB_BETA_USER_DATA).get()[user_id]
        user_group_list = user_info.get(MY_GROUP_LIST, {})
        if group_key not in user_group_list:
            raise BadRequestError('User ID not in group')

        user_name = user_info.get(NICKNAME, '')

        group_chatting_tokens = group_member_tokens[CHATTING]
        group_chatting_tokens.pop(user_id, None)

        target_tokens = list(chain(*group_chatting_tokens.values()))

        group_info = root_ref.child(DB_BETA_GROUP_INFO).get()[group_key]
        group_name = group_info.get(GROUP_NAME, '')

        data = {'host': HOST, 'path': CHATTING_PATH, 'query': f'?{GROUP_KEY}={group_key}', 'senderId': user_id}

        if target_tokens:
            send_fcm_multicast(
                tokens=target_tokens,
                title=user_name,
                body=chat,
                subtitle=group_name,
                data=data,
                category='Group-Chat-Alert',
            )

    return handler.response('', 201)


@groups_api_module.route('/groups/workout-alert', methods=['POST'])
@common_set_up(module=groups_api_module)
def groups_workout_alert_api(request: Request, root_ref: Reference, handler: APIHandler) -> Response:
    user_id = request.query_params.get('UserId')
    if not user_id:
        raise BadRequestError('Missing user ID in the request')

    group_member_tokens = root_ref.child(DB_BETA_GROUP_MEMBER_TOKENS).get()
    user_data = root_ref.child(DB_BETA_USER_DATA).get()
    user_group_list = user_data[user_id].get(MY_GROUP_LIST)

    if not user_group_list:
        return handler.response('', 201)

    user_name = user_data[user_id].get(NICKNAME, '')

    recipient_tokens = {}

    for group_key in user_group_list.keys():
        if group_key == DUX_GROUP_KEY:
            continue

        member_tokens = group_member_tokens.get(group_key)

        if not (member_tokens and member_tokens.get(WORKOUT)):
            continue

        group_workout_tokens = member_tokens[WORKOUT]
        group_workout_tokens.pop(user_id, None)

        for member_key, token_list in group_workout_tokens.items():
            if token_list:
                recipient_tokens[member_key] = {'tokens': token_list, 'group_key': group_key}

    for member_key, recipient_info in recipient_tokens.items():
        group_key = recipient_info['group_key']
        target_tokens = recipient_info['tokens']

        member_name = user_data[member_key].get(NICKNAME, '')
        group_name = root_ref.child(DB_BETA_GROUP_INFO).get()[group_key].get(GROUP_NAME, '')

        data = {'host': HOST, 'path': WORKOUT_PATH, 'query': f'?{GROUP_KEY}={group_key}', 'senderId': user_id}

        title = f'{user_name}님이 운동을 시작했어요!'
        body = f'{member_name}님도 와서 같이 운동해요!'

        send_fcm_multicast(
            tokens=target_tokens, title=title, body=body, subtitle=group_name, data=data, category='Group-Workout-Alert'
        )

    return handler.response('', 201)


@groups_api_module.route('/groups/master', methods=['POST', 'DELETE'])
@common_set_up(module=groups_api_module)
def master_change_api(request: Request, root_ref: Reference, handler: APIHandler) -> Response:
    user_id = request.query_params.get('UserId')
    if not user_id:
        raise BadRequestError('Missing user ID in the request')

    user_profile = root_ref.child(DB_BETA_USER_DATA).child(user_id).get()
    if not user_profile:
        raise BadRequestError(f'Invalid user [{user_id}]')

    def update_group_master(user_id, new_master_user_key, group_key, active_user: bool = True):
        user_change_log_ref = root_ref.child(DB_BETA_USER_DATA_CHANGE_LOG).child(user_id)
        new_master_change_log_ref = root_ref.child(DB_BETA_USER_DATA_CHANGE_LOG).child(new_master_user_key)
        group_logging_ref = root_ref.child(DB_BETA_GROUP_LOGGING).child(group_key)

        new_master_profile = root_ref.child(DB_BETA_USER_DATA).child(new_master_user_key).get()
        group_data = root_ref.child(DB_BETA_GROUP_INFO).child(group_key).get()
        group_name = group_data.get(GROUP_NAME)

        if not group_data or not group_name:
            raise BadRequestError(f'Group [{group_key}] is not valid')

        devices = new_master_profile.get(DEVICES)
        nickname = new_master_profile.get(NICKNAME)

        update = {}
        update[f'{DB_BETA_GROUP_INFO}/{group_key}/MasterUserKey'] = new_master_user_key
        update[f'{DB_BETA_GROUP_INFO}/{group_key}/MasterNickname'] = nickname
        update[f'{DB_BETA_USER_DATA}/{new_master_user_key}/{MY_GROUP_LIST}/{group_key}/IsMaster'] = True

        update[f'{DB_BETA_USER_DATA_CHANGE_LOG}/{new_master_user_key}/{new_master_change_log_ref.push().key}'] = {
            'ExecutionType': 'ChaliceApi',
            'EventName': 'MasterAppointed',
            'EventTimeUtc': handler.timestamp,
            'NewData': group_key,
        }
        update[f'{DB_BETA_GROUP_LOGGING}/{group_key}/{group_logging_ref.push().key}'] = {
            'ExecutionType': 'ChaliceApi',
            'EventName': 'MasterChanged',
            'EventTimeUtc': handler.timestamp,
            'Value': {'OldMasterKey': user_id, 'NewMasterKey': new_master_user_key},
        }

        if active_user:
            update[f'{DB_BETA_USER_DATA}/{user_id}/{MY_GROUP_LIST}/{group_key}/IsMaster'] = None
            update[f'{DB_BETA_USER_DATA_CHANGE_LOG}/{user_id}/{user_change_log_ref.push().key}'] = {
                'ExecutionType': 'ChaliceApi',
                'EventName': 'ChangedToMember',
                'EventTimeUtc': handler.timestamp,
                'NewData': group_key,
            }
        root_ref.update(update)

        if new_master_profile and isinstance(devices, dict) and nickname:
            target_tokens = [device[TOKEN] for device in devices.values() if device.get(TOKEN)]
            print(target_tokens)

            if target_tokens:
                body = f'축하드려요! {nickname}님이 새로운 그룹장이 되셨어요!'
                data = {'host': HOST, 'path': WORKOUT_PATH, 'query': f'?{GROUP_KEY}={group_key}', 'senderId': user_id}
                send_fcm_multicast(
                    tokens=target_tokens, title=group_name, body=body, data=data, category='Group-Manage-Alert'
                )

    if request.method == 'POST':
        new_master_info = request.json_body
        if not new_master_info:
            raise BadRequestError('Missing body in the request')

        group_key = new_master_info.get(GROUP_KEY)
        new_master_user_key = new_master_info.get('NewMasterUserKey')
        if not group_key:
            raise BadRequestError('Missing group key in the request')
        if not new_master_user_key:
            raise BadRequestError('Missing new master user key in the request')

        update_group_master(user_id=user_id, new_master_user_key=new_master_user_key, group_key=group_key)

        return handler.response('', 201)

    if request.method == 'DELETE':
        all_group_member = root_ref.child(DB_BETA_GROUP_MEMBER).get()

        user_group_list = user_profile.get(MY_GROUP_LIST)
        if not user_group_list:
            return handler.response('', 204)

        user_master_groups = [
            group_key for group_key, user_group_data in user_group_list.items() if user_group_data.get('IsMaster')
        ]
        for master_group_key in user_master_groups:
            if master_group_key not in all_group_member:
                continue

            master_group_member = all_group_member[master_group_key]
            if DELETED in master_group_member and master_group_member.get(DELETED):
                continue

            master_group_member.pop(user_id, None)

            if not master_group_member:
                root_ref.child(DB_BETA_GROUP_INFO).child(master_group_key).delete()
                continue

            new_master_user_key = random.choice(list(master_group_member.keys()))
            update_group_master(
                user_id=user_id, new_master_user_key=new_master_user_key, group_key=master_group_key, active_user=False
            )

        return handler.response('', 204)
