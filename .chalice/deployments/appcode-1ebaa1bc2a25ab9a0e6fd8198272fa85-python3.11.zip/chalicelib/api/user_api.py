from chalice import BadRequestError
from chalice import Blueprint
from chalice.app import Request, Response
from firebase_admin.db import Reference

from chalicelib.api_setup import APIHandler, common_set_up
from chalicelib.core import create_change_log_data_set

user_api_module = Blueprint(__name__)


@user_api_module.route('/users', methods=['PUT'])
@common_set_up(module=user_api_module)
def user_api(request: Request, root_ref: Reference, handler: APIHandler) -> Response:
    user_id = request.query_params.get('UserId')
    if not user_id:
        raise BadRequestError('Missing user ID in the request')

    user_info = request.json_body
    if not user_info:
        raise BadRequestError('Missing body in the request')

    user_ref = root_ref.child('beta_user_data').child(user_id)
    user_data_change_log_ref = root_ref.child('beta_user_data_change_log').child(user_id)

    if request.method == 'PUT':
        for ref_key, new_user_data in user_info.items():
            old_user_data = user_ref.child(ref_key).get()

            user_ref.update({ref_key: new_user_data})

            user_data_change_log_ref.push().set(
                create_change_log_data_set(ref_key=ref_key, old_data=old_user_data, new_data=new_user_data)
            )

        return handler.response('', 200)
