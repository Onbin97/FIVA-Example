def get_secret_value() -> dict:
    pass
