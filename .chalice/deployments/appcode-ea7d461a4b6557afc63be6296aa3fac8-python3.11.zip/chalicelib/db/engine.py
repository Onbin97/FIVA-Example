import os

import firebase_admin as admin
from firebase_admin import credentials
from firebase_admin import db

# 어드민 계정 정보를 이용해 firebase-admin을 초기화
if "cred" not in dir():
    server_env = os.getenv("SERVER_ENV")
    db_url = os.getenv("DB_URL")

    prod = os.getenv("SERVER_ENV") == "prod"

    cred = credentials.Certificate('chalicelib/firebase/fiva_firebase_admin.json')
    admin.initialize_app(cred, {"databaseURL": db_url % ("default" if prod else "develop")})
    ref = db.reference()
