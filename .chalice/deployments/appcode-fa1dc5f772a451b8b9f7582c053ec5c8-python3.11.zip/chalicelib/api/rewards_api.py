import random

from chalice import Blueprint
from chalice import BadRequestError
from chalice.app import Request, Response
from firebase_admin.db import Reference

from chalicelib.api_setup import APIHandler, common_set_up
from chalicelib.core import create_change_log_data_set
from chalicelib.constants.common import EVENT_TIME_UTC, REWARD_CATEGORY, REWARD_KEY
from chalicelib.constants.db_ref_key import DB_BETA_USER_DATA_CHANGE_LOG, DB_BETA_USER_ITEM_DATA, DB_REWARD_DATA


rewards_api_module = Blueprint(__name__)


DB_REWARD_LOGS = 'reward_logs'

ITEM_LIST = 'ItemList'
TYPE_TEXT = 'TypeText'

REWARD_ITEM = 'RewardItem'

FIXED = 'Fixed'
RANDOM = 'Random'
SET = 'Set'


@rewards_api_module.route('/rewards', methods=['POST'])
@common_set_up(module=rewards_api_module)
def rewards_api(request: Request, root_ref: Reference, handler: APIHandler) -> Response:
    user_id = request.query_params.get('UserId')
    if not user_id:
        raise BadRequestError('Missing user ID in the request')

    reward_info = request.json_body
    if not reward_info:
        raise BadRequestError('Missing body in the request')

    reward_key = reward_info.get(REWARD_KEY)
    reward_category = reward_info.get(REWARD_CATEGORY)

    reward = root_ref.child(DB_REWARD_DATA).child(reward_category).child(reward_key).get()
    if not reward:
        raise BadRequestError('Invalid reward information')

    user_item_data_ref = root_ref.child(DB_BETA_USER_ITEM_DATA).child(user_id)

    if reward[TYPE_TEXT] == RANDOM:
        user_items = {item_data for item_data in user_item_data_ref.get()}  # Set으로 변환하여 검색 성능 개선
        reward_item_list = [item for item in reward[ITEM_LIST] if item not in user_items]

        item_list = random.choices(reward_item_list or reward[ITEM_LIST])
    else:
        item_list = reward[ITEM_LIST]

    user_item_data_ref.update({item: handler.timestamp for item in item_list})

    root_ref.child(DB_BETA_USER_DATA_CHANGE_LOG).child(user_id).push().set(
        create_change_log_data_set(ref_key=REWARD_ITEM, new_data=item_list)
    )

    root_ref.child(DB_REWARD_LOGS).child(user_id).push().set(
        {
            REWARD_KEY: reward_key,
            REWARD_CATEGORY: reward_category,
            ITEM_LIST: item_list,
            EVENT_TIME_UTC: handler.timestamp,
        }
    )

    response = {ITEM_LIST: item_list}
    return handler.response(response, 201)
