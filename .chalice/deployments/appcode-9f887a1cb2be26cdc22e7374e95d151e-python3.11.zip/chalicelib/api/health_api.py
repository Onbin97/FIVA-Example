from chalice import BadRequestError
from chalice import Blueprint
from chalice.app import Request, Response
from firebase_admin.db import Reference

from chalicelib.api_setup import APIHandler, common_set_up
from chalicelib.constants.common import (
    CALCULATED_LOGS,
    CLASS_INFO,
    DATETIME_KEY,
    DURATION_SEC,
    EVENT_TIME_UTC,
    JOIN_COUNT,
    KCAL,
    LOGS,
    JOIN_COUNT_STATUS,
    TOTAL_CALROIES_BURNED,
    TOTAL_WORKOUT_TIME,
)
from chalicelib.constants.db_ref_key import (
    BETA_USER_DATA,
    BETA_USER_DATA_CHANGE_LOG,
    BETA_USER_WORKOUT_LOGS,
    CONTENT_INFO,
)
from chalicelib.core import create_change_log_data_set


health_api_module = Blueprint(__name__)


@health_api_module.route('/health/init', methods=['POST'])
@common_set_up(module=health_api_module)
def health_data_init_api(request: Request, root_ref: Reference, handler: APIHandler) -> Response:
    user_id = request.query_params.get('UserId')
    if not user_id:
        raise BadRequestError('Missing user ID in the request')

    body = request.json_body
    if not body:
        raise BadRequestError('Missing body in the request')

    class_info = body.get(CLASS_INFO)
    class_ref = root_ref.child(CONTENT_INFO).child(class_info.get('Type')).child(class_info.get('Key'))
    class_data_info = {DURATION_SEC: class_ref.child(DURATION_SEC).get(), KCAL: class_ref.child(KCAL).get()}

    ref_key = body.get(DATETIME_KEY)
    user_workout_logs_ref = root_ref.child(BETA_USER_WORKOUT_LOGS).child(user_id)

    if user_workout_logs_ref.child(ref_key).get():
        return handler.response({'Initialized': True}, 200)

    user_workout_logs_ref.update(
        {ref_key: {CLASS_INFO: class_data_info, EVENT_TIME_UTC: handler.timestamp, JOIN_COUNT_STATUS: False}}
    )

    return handler.response('', 201)


@health_api_module.route('/health/logs', methods=['POST'])
@common_set_up(module=health_api_module)
def health_data_register_log_api(request: Request, root_ref: Reference, handler: APIHandler) -> Response:
    user_id = request.query_params.get('UserId')
    if not user_id:
        raise BadRequestError('Missing user ID in the request')

    body = request.json_body
    if not body:
        raise BadRequestError('Missing body in the request')

    log_info = body.get('LogInfo')
    ref_key = body.get(DATETIME_KEY)

    user_workout_logs_ref = root_ref.child(BETA_USER_WORKOUT_LOGS).child(user_id).child(ref_key)

    log_info[EVENT_TIME_UTC] = handler.timestamp
    user_workout_logs_ref.child(LOGS).push().set(log_info)

    if log_info['EventType'] == 'Closed':
        user_ref = root_ref.child(BETA_USER_DATA).child(user_id)
        user_data_change_log_ref = root_ref.child(BETA_USER_DATA_CHANGE_LOG).child(user_id)

        user_data_info = user_ref.get()

        user_join_count = user_data_info.get(JOIN_COUNT) or 0
        user_total_workout_time = user_data_info.get(TOTAL_WORKOUT_TIME) or 0
        user_total_calories_burned = user_data_info.get(TOTAL_CALROIES_BURNED) or 0

        user_workout_data_info = user_workout_logs_ref.get()

        user_logs = user_workout_logs_ref.child(LOGS).get()

        user_workout_logs_ref.child(CALCULATED_LOGS).update(user_logs)
        user_workout_logs_ref.child(LOGS).delete()

        class_duration = user_workout_data_info[CLASS_INFO][DURATION_SEC]
        class_calories = user_workout_data_info[CLASS_INFO][KCAL]

        workout_duration = sum([float(value[DURATION_SEC]) for value in user_logs.values()])
        workout_calories = round((class_calories / class_duration) * workout_duration, 1)

        calculated_logs = user_workout_logs_ref.child(CALCULATED_LOGS).get()
        total_duration = sum(float(info[DURATION_SEC]) for info in calculated_logs.values())

        join_count_status = user_workout_data_info[JOIN_COUNT_STATUS]
        workout_succeeded = total_duration >= 0.7 * class_duration

        if not join_count_status and workout_succeeded:
            new_user_join_count = user_join_count + 1
            user_ref.update({JOIN_COUNT: new_user_join_count})
            user_data_change_log_ref.push().set(
                create_change_log_data_set(ref_key=JOIN_COUNT, new_data=new_user_join_count, old_data=user_join_count)
            )
            user_workout_logs_ref.update({JOIN_COUNT_STATUS: True})

        old_user_data = {TOTAL_WORKOUT_TIME: user_total_workout_time, TOTAL_CALROIES_BURNED: user_total_calories_burned}
        new_user_data = {
            TOTAL_WORKOUT_TIME: user_total_workout_time + workout_duration,
            TOTAL_CALROIES_BURNED: user_total_calories_burned + workout_calories,
        }
        user_ref.update(new_user_data)

        user_data_change_log_ref.push().set(
            create_change_log_data_set(ref_key='WorkoutRecord', new_data=new_user_data, old_data=old_user_data)
        )

        return handler.response('', 201)

    return handler.response('', 201)
