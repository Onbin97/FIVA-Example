import os
from chalice import Chalice

from chalicelib.api import user_api, test_api

server_env = os.getenv('SERVER_ENV')
app = Chalice(app_name=f'fiva-{server_env}')


# FIVA API
app.register_blueprint(test_api.test_api_module)
app.register_blueprint(user_api.user_api_module)
