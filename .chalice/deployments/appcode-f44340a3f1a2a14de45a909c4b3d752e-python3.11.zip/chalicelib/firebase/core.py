import os

from datetime import datetime
from typing import Optional

from firebase_admin import messaging


def create_fcm_datetime_topic(fcm_datetime: datetime) -> str:
    date_str = fcm_datetime.strftime('%y%m%d')
    time_str = fcm_datetime.strftime('%H')

    topic = (
        f'schedule_{date_str}_{time_str}'
        if os.getenv('SERVER_ENV') == 'prod'
        else f'test_schedule_{date_str}_{time_str}'
    )

    return topic


def send_fcm_to_topic(topic: str, title: str, body: str) -> str:
    message = messaging.Message(notification=messaging.Notification(title=title, body=body), topic=topic)
    response = messaging.send(message)
    return response
