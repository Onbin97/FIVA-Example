import random

from datetime import datetime, timedelta, timezone
from typing import Any

from chalice import BadRequestError
from chalice import Blueprint
from chalice.app import Request, Response
from firebase_admin.db import Reference

from chalicelib.api_setup import APIHandler, common_set_up
from chalicelib.constants.common import (
    ACTIVITY,
    BODY,
    CONTENT_INFO,
    CONTENT_KEY,
    CONTENT_TYPE,
    DATETIME_KEY,
    DURATION_SEC,
    FCM_METHOD,
    FILTER_TYPES,
    KCAL,
    LIVE_TITLE,
    TITLE,
    USER_DEVICES,
    USER_KEY,
)
from chalicelib.constants.db_ref_key import DB_CONTENT_INFO, DB_LIVE_SCHEDULE_INFO
from chalicelib.core import create_activity_after_24_notification_schedule


fcm_api_module = Blueprint(__name__)


class FcmAPIHandler:
    def __init__(self, root_ref: Reference, user_id: str, body: dict = {}):
        self.root_ref = root_ref
        self.user_id = user_id
        self.default_fcm_title = '안녕! FIVA에요'

        self.activity_fcm_func_mapping = {
            'DefaultWorkout': lambda: self._schedule_default_workout_remind(body),
            'SkiGame': self._schedule_ski_game_remind,
        }

    def _schedule_default_workout_remind(self, body: dict):
        content_type = body[CONTENT_INFO][CONTENT_TYPE]
        content_key = body[CONTENT_INFO][CONTENT_KEY]

        content = self.root_ref.child(DB_CONTENT_INFO).child(content_type).child(content_key).get()
        if not content:
            raise BadRequestError('Invalid content')
        content_info = {
            CONTENT_TYPE: content_type,
            CONTENT_KEY: content_key,
            DURATION_SEC: content[DURATION_SEC],
            KCAL: content[KCAL],
            DATETIME_KEY: content['Date'],
            FILTER_TYPES: content.get(FILTER_TYPES, []),
            f'{TITLE}Text': content.get(f'{TITLE}Text'),
        }

        nickname = '{Nickname}'
        fcm_body = None
        content_type = content_info[CONTENT_TYPE]
        if content_type == 'LiveList':
            date_format = '%Y-%m-%d %I:%M%p'
            date_obj = datetime.strptime(content_info[DATETIME_KEY], date_format)
            class_hour = date_obj.hour

            live_index = 0
            if class_hour == 21:
                live_index = 1
            elif class_hour == 22:
                live_index = 2

            tomorrow = date_obj + timedelta(days=1)
            tomorrow_month_key = tomorrow.strftime('%Y-%m')
            tomorrow_datetime_key = tomorrow.strftime(date_format)
            live_title = (
                self.root_ref.child(DB_LIVE_SCHEDULE_INFO)
                .child(f'live_class_{live_index}')
                .child(tomorrow_month_key)
                .child(tomorrow_datetime_key)
                .child(LIVE_TITLE)
                .get()
            )
            fcm_body = f'{nickname}님! 오늘은 "{live_title}" 클래스 어때요?'

        if content_type == 'VodList':
            target_text_map = {'FULL': '전신', 'UPPER': '상체', 'LOWER': '하체', 'CORE': '코어'}
            target_text_list = ['FULL', 'UPPER', 'LOWER', 'CORE']

            target_text_list = [
                target_text for target_text in target_text_list if target_text not in content_info[FILTER_TYPES]
            ]

            content_title = content_info[f'{TITLE}Text']

            fcm_body = f'{nickname}님! 어제 "{content_title}"은 어떠셨나요?\n\
오늘은 {target_text_map[random.choice(target_text_list)]}운동 어때요?'

        if fcm_body:
            return create_activity_after_24_notification_schedule(
                user_id=self.user_id,
                payload={
                    FCM_METHOD: USER_DEVICES,
                    USER_KEY: self.user_id,
                    TITLE: self.default_fcm_title,
                    BODY: fcm_body,
                },
            )

    def _schedule_ski_game_remind(self):
        fcm_body = '{Nickname}님! 오늘도 스키 게임 몬스터 물리치고 신기록에 도전해보세요!'
        return create_activity_after_24_notification_schedule(
            user_id=self.user_id,
            payload={FCM_METHOD: USER_DEVICES, USER_KEY: self.user_id, TITLE: self.default_fcm_title, BODY: fcm_body},
        )


@fcm_api_module.route('/fcm/act-remind', methods=['POST'])
@common_set_up(module=fcm_api_module)
def workout_log_init_api(request: Request, root_ref: Reference, handler: APIHandler) -> Response:
    user_id = request.query_params.get('UserId')
    if not user_id:
        raise BadRequestError('Missing user ID in the request')

    body = request.json_body
    if not body:
        raise BadRequestError('Missing body in the request')

    activity = body.pop(ACTIVITY, None)
    if not activity:
        raise BadRequestError('Missing activity in the request')

    fcm_api_handler = FcmAPIHandler(root_ref=root_ref, user_id=user_id, body=body)
    remind_func = fcm_api_handler.activity_fcm_func_mapping.get(activity)
    if remind_func:
        remind_func()

    return handler.response('', 201)
