from chalice import BadRequestError
from chalice import Blueprint
from chalice.app import Request, Response
from firebase_admin.db import Reference

from chalicelib.api_setup import APIHandler, common_set_up

test_api_module = Blueprint(__name__)


@test_api_module.route('/test', methods=['GET', 'POST', 'PATCH', 'DELETE'])
@common_set_up(module=test_api_module)
def test_api(request: Request, root_ref: Reference, handler: APIHandler) -> Response:
    body = request.json_body

    user_id = request.query_params.get('UserId')
    if not user_id:
        raise BadRequestError('Missing user ID in the request')

    if request.method == 'GET':
        user_info = root_ref.child("beta_user_data").child(user_id).get()

        return handler.response(user_info, 200)

    if request.method == 'POST':
        user_info = body.get('UserInfo')
        root_ref.child("beta_user_data").child(user_id).set(user_info)

        return handler.response('', 201)

    if request.method == 'PATCH':
        user_info = body.get('UserInfo')
        root_ref.child("beta_user_data").child(user_id).update(user_info)

        return handler.response('', 200)

    if request.method == 'DELETE':
        root_ref.child("beta_user_data").child(user_id).delete()

        return handler.response('', 204)


from chalicelib.core import create_event_bridge_schedule
import boto3

#
# @test_api_module.route('/t', methods=['GET', 'POST', 'PATCH', 'DELETE'])
# @common_set_up(module=test_api_module)
# def t_api(request: Request, root_ref: Reference, handler: APIHandler) -> Response:
#     client = None
#     client = boto3.client('scheduler')
#
#     # create_event_bridge_schedule(client=client,payload=)
#     return
