import certifi
import os
import ssl

from slack_sdk import WebClient
from slack_sdk.errors import SlackApiError

ssl._create_default_https_context = ssl._create_unverified_context
ssl_context = ssl.create_default_context(cafile=certifi.where())


def post_slack_message(channel_id: str, token: str, text: str) -> None:
    if os.getenv('SERVER_ENV') == 'dev':
        return

    client = WebClient(token=token, ssl=ssl_context)

    try:
        client.chat_postMessage(channel=channel_id, text=text)

    except SlackApiError as e:
        print(e)
        assert e.response["error"]
