from itertools import chain

from chalice import Blueprint
from chalice import BadRequestError
from chalice.app import Request, Response
from firebase_admin.db import Reference

from chalicelib.api_setup import APIHandler, common_set_up
from chalicelib.constants.common import GROUP_KEY, GROUP_NAME, NICKNAME, WORKOUT
from chalicelib.constants.db_ref_key import DB_BETA_GROUP_INFO, DB_BETA_GROUP_MEMBER_TOKENS, DB_BETA_USER_DATA
from chalicelib.firebase.core import send_fcm_multicast


groups_api_module = Blueprint(__name__)

HOST = 'group'
WORKOUT_PATH = '/lounge'
CHATTING_PATH = '/lounge/chatting'


@groups_api_module.route('/groups/chat-alert', methods=['POST'])
@common_set_up(module=groups_api_module)
def lounge_chat_alert_api(request: Request, root_ref: Reference, handler: APIHandler) -> Response:
    user_id = request.query_params.get('UserId')
    if not user_id:
        raise BadRequestError('Missing user ID in the request')

    chat = request.json_body.get('Chat')
    if not chat:
        raise BadRequestError('Invalid chat')

    group_key = request.query_params.get(GROUP_KEY)
    group_member_tokens = root_ref.child(DB_BETA_GROUP_MEMBER_TOKENS).child(group_key).get()

    if group_member_tokens and group_member_tokens.get('Chatting'):

        group_chatting_tokens = group_member_tokens['Chatting']
        if user_id not in group_chatting_tokens:
            raise BadRequestError('User ID not in group')

        group_chatting_tokens.pop(user_id)
        target_tokens = list(chain(*group_chatting_tokens.values()))

        user_info = root_ref.child(DB_BETA_USER_DATA).get()[user_id]
        user_name = user_info.get(NICKNAME, '')

        group_info = root_ref.child(DB_BETA_GROUP_INFO).get()[group_key]
        group_name = group_info.get(GROUP_NAME, '')

        data = {'host': HOST, 'path': CHATTING_PATH, 'query': f'?{GROUP_KEY}={group_key}', 'senderId': user_id}

        if target_tokens:
            send_fcm_multicast(tokens=target_tokens, title=user_name, body=chat, subtitle=group_name, data=data)

    return handler.response('', 201)


@groups_api_module.route('/groups/workout-alert', methods=['POST'])
@common_set_up(module=groups_api_module)
def groups_workout_alert_api(request: Request, root_ref: Reference, handler: APIHandler) -> Response:
    user_id = request.query_params.get('UserId')
    if not user_id:
        raise BadRequestError('Missing user ID in the request')

    group_member_tokens = root_ref.child(DB_BETA_GROUP_MEMBER_TOKENS).get()
    user_data = root_ref.child(DB_BETA_USER_DATA).get()

    user_group_list = user_data[user_id].get('MyGroupList')
    if not user_group_list:
        return handler.response('', 201)

    if user_group_list:
        for group_key in user_group_list.keys():
            group_member_tokens = group_member_tokens.get(group_key)
            if group_member_tokens and group_member_tokens.get(WORKOUT):
                group_workout_tokens = group_member_tokens[WORKOUT]

                group_workout_tokens.pop(user_id)

                user_name = user_data[user_id].get(NICKNAME, '')

                for member_key, token_list in group_workout_tokens.items():
                    target_tokens = token_list

                    member_name = user_data[member_key].get(NICKNAME, '')

                    group_info = root_ref.child(DB_BETA_GROUP_INFO).get()[group_key]
                    group_name = group_info.get(GROUP_NAME, '')

                    data = {'host': HOST, 'path': WORKOUT_PATH, 'senderId': user_id}
                    title = f'{user_name}님이 운동을 시작했어요!'
                    body = f'{user_name}님에게 질 수 없죠! {member_name}님도 와서 같이 운동해요!'

                    if target_tokens:
                        send_fcm_multicast(tokens=target_tokens, title=title, body=body, subtitle=group_name, data=data)

    return handler.response('', 201)
