import os

from chalice import Blueprint, Rate

from chalicelib.db.engine import root_ref
from chalicelib.constants.common import CONTENT_KEY, NICKNAME
from chalicelib.constants.db_ref_key import DB_CONTENT_FEEDBACK
from chalicelib.slack_bot import post_slack_message


fiva_slack_module = Blueprint(__name__)

SENT = 'Sent'


@fiva_slack_module.schedule(Rate(2, Rate.MINUTES))
def schedule_content_feedback_alert(event) -> None:
    content_feedback_ref = root_ref.child(DB_CONTENT_FEEDBACK)
    content_feedback = content_feedback_ref.get()

    for feedback_info in content_feedback.values():
        nickname = feedback_info.get(NICKNAME)
        feedback_list = feedback_info.get('ResultTypesKor')

        if not feedback_info.get(SENT) and nickname and feedback_list:
            content_key = feedback_info.get(CONTENT_KEY, '')
            feedback_str = ', '.join(feedback_list)
            text = f'컨텐츠: {content_key}\n닉네임: {nickname}\n피드백: {feedback_str}'
            post_slack_message(
                channel_id=os.getenv('SLACK_CONTENT_REVIEW_BOT_CHANNEL_ID'),
                token=os.getenv('SLACK_TOKEN_SERVER'),
                text=text,
            )
            feedback_info[SENT] = True

    content_feedback_ref.update(content_feedback)
