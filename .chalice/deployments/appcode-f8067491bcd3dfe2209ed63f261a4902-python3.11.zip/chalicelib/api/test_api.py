from chalice import Blueprint

from chalicelib.db.engine import ref

test_api_module = Blueprint(__name__)

@test_api_module.route('/test', methods=['GET', 'POST', 'PATCH', 'DELETE'])
def test_api():
    request = test_api_module.current_request
    body = request.json_body

    if request.method == 'GET':
        user_id = request.query_params.get('userId')
        user_info = ref.child("beta_user_data").child(user_id).get()
        return user_info
    
    if request.method == 'POST':
        user_id = body.get('userId')
        user_info = body.get('userInfo')
        ref.child("beta_user_data").child(user_id).set(user_info)
        return {'msg': 'success'}
    
    if request.method == 'PATCH':
        user_id = body.get('userId')
        user_info = body.get('userInfo')
        
        ref.child("beta_user_data").child(user_id).update(user_info)
        return {'msg': 'success'}
    
    if request.method == 'DELETE':
        user_id = body.get('userId')

        ref.child("beta_user_data").child(user_id).delete()
        return {'msg': 'success'}
        