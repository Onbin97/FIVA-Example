import os
from copy import deepcopy
from datetime import datetime, timedelta, timezone

from chalice import Blueprint, Rate
from chalice import BadRequestError
from chalice.app import Request, Response
from firebase_admin.db import Reference

from chalicelib.api_setup import APIHandler, common_set_up
from chalicelib.core import create_change_log_data_set, format_utc_timestamp, format_utc_timestamp_to_datetime
from chalicelib.constants.common import (
    ANIMATION_PLAYED_DOWN,
    ANIMATION_PLAYED_UP,
    COSTUME_LIST,
    DELETED,
    FLOOR_KEY,
    FLOOR_USER_COUNT,
    FLOORS,
    LAST_ACTIVITY_DATA,
    MAP_KEY,
    NICKNAME,
    PERCENTAGE,
    PREV_FLOOR,
    UPDATED_TIME_UTC,
    USER_LIST,
    PARTIAL_COMPLETED_TIME_UTC,
)
from chalicelib.constants.db_ref_key import (
    DB_BETA_USER_DATA,
    DB_BETA_USER_DATA_CHANGE_LOG,
    DB_BETA_USER_FLOOR_DATA,
    DB_STAIR_CLIMBING_MAP_DATA,
)
from chalicelib.db.engine import root_ref
from chalicelib.slack_bot import post_slack_message


stair_climbing_api_module = Blueprint(__name__)

TUTORIAL_MAP = 'map0'


@stair_climbing_api_module.schedule('cron(0 15 * * ? *)')
def schedule_floor_data(event) -> None:
    try:
        user_floor_data_ref = root_ref.child(DB_BETA_USER_FLOOR_DATA)
        user_floor_data = user_floor_data_ref.get()

        copied_user_floor_data = deepcopy(user_floor_data)

        for user_key, data in user_floor_data.items():
            updated_time_utc = format_utc_timestamp_to_datetime(data[UPDATED_TIME_UTC])
            last_completed_time = updated_time_utc

            if PARTIAL_COMPLETED_TIME_UTC in data:
                partial_completed_time_utc = format_utc_timestamp_to_datetime(data[PARTIAL_COMPLETED_TIME_UTC])
                if partial_completed_time_utc > updated_time_utc:
                    last_completed_time = partial_completed_time_utc
                    copied_user_floor_data[user_key][UPDATED_TIME_UTC] = format_utc_timestamp(
                        partial_completed_time_utc
                    )

            limit_time_utc = last_completed_time + timedelta(days=3)
            current_time_utc = datetime.now(timezone.utc)

            if not data[FLOOR_KEY] or data[MAP_KEY] == TUTORIAL_MAP:
                continue

            if current_time_utc > limit_time_utc:
                if LAST_ACTIVITY_DATA not in data:
                    copied_user_floor_data[user_key][LAST_ACTIVITY_DATA] = data

                copied_user_floor_data[user_key][FLOOR_KEY] = data[FLOOR_KEY] - 1
                copied_user_floor_data[user_key][UPDATED_TIME_UTC] = format_utc_timestamp(limit_time_utc)
                copied_user_floor_data[user_key][ANIMATION_PLAYED_DOWN] = False
                copied_user_floor_data[user_key][ANIMATION_PLAYED_UP] = None

        user_floor_data_ref.update(copied_user_floor_data)

    except Exception as e:
        post_slack_message(
            channel_id=os.getenv('SLACK_DEV_CHANNEL_ID'),
            token=os.getenv('SLACK_TOKEN_SERVER'),
            text=f'User Floor Data Update Failed 🚨\n\nError Message:\n```ERROR: {e}```',
        )
        print(e)


@stair_climbing_api_module.schedule(Rate(5, Rate.MINUTES))
def schedule_stair_climbing_data(event) -> None:
    # @stair_climbing_api_module.route('/t')
    # def schedule_stair_climbing_data() -> None:
    try:
        stair_map_data = {}

        user_floor_data = root_ref.child(DB_BETA_USER_FLOOR_DATA).get()
        total_climbing_user_count = len(user_floor_data)

        # Collect user floor data and create floor_data_to_update
        for user_key, data in user_floor_data.items():
            map_key = data[MAP_KEY]

            if map_key == 'map0':
                continue

            if map_key not in stair_map_data:
                stair_map_data[map_key] = {}

            floor = stair_map_data[map_key]
            if data[FLOOR_KEY] not in floor:
                floor[data[FLOOR_KEY]] = [{user_key: data[UPDATED_TIME_UTC]}]
            else:
                floor[data[FLOOR_KEY]].append({user_key: data[UPDATED_TIME_UTC]})

        # Load stair climbing map data
        stair_climbing_map_ref = root_ref.child(DB_STAIR_CLIMBING_MAP_DATA)
        stair_climbing_map = stair_climbing_map_ref.get()

        climbing_user_count = 0
        user_profile_data = root_ref.child(DB_BETA_USER_DATA).get()

        sorted_stair_map_data = dict(sorted(stair_map_data.items(), key=lambda x: int(x[0].replace('map', ''))))

        # Update stair_climbing_map based on floor_data_to_update
        for map_key, floor_data in sorted_stair_map_data.items():
            sorted_floor_data = dict(sorted(floor_data.items(), reverse=True))
            for floor, user_data_list in sorted_floor_data.items():
                current_floor_data = stair_climbing_map[map_key][FLOORS][floor]

                user_data_list.sort(
                    key=lambda x: datetime.strptime(list(x.values())[0], '%Y-%m-%d %I:%M:%S.%f%p'), reverse=True
                )
                floor_user_count = len(user_data_list)
                current_floor_data[FLOOR_USER_COUNT] = floor_user_count

                percentage = (climbing_user_count + 1) / total_climbing_user_count if climbing_user_count else 0

                current_floor_data[PERCENTAGE] = percentage

                climbing_user_count += floor_user_count

                recent_user_data = {}
                for recent_user in user_data_list:
                    if len(recent_user_data) >= 3:
                        break
                    for user_key in recent_user:
                        user_profile = user_profile_data.get(user_key, {})

                        if user_profile and DELETED not in user_profile:
                            recent_user_data[user_key] = {
                                NICKNAME: user_profile.get(NICKNAME),
                                COSTUME_LIST: user_profile.get(COSTUME_LIST),
                            }
                current_floor_data[USER_LIST] = recent_user_data

        stair_climbing_map_ref.update(stair_climbing_map)

    except Exception as e:
        post_slack_message(
            channel_id=os.getenv('SLACK_DEV_CHANNEL_ID'),
            token=os.getenv('SLACK_TOKEN_SERVER'),
            text=f'Climbing Stair Data Update Failed 🚨\n\nError Message:\n```ERROR: {e}```',
        )
        print(e)


@stair_climbing_api_module.route('/stair', methods=['POST'])
@common_set_up(module=stair_climbing_api_module)
def climbing_stair_api(request: Request, root_ref: Reference, handler: APIHandler) -> Response:
    user_id = request.query_params.get('UserId')
    if not user_id:
        raise BadRequestError('Missing user ID in the request')

    stair_floor_info = request.json_body
    if not stair_floor_info:
        raise BadRequestError('Missing body in the request')

    stair_climbing_map_ref = root_ref.child(DB_STAIR_CLIMBING_MAP_DATA)
    stair_climbing_map = stair_climbing_map_ref.get()

    map_key = stair_floor_info[MAP_KEY]
    if map_key not in stair_climbing_map:
        raise BadRequestError('Invalid map key')

    floor_key = stair_floor_info[FLOOR_KEY]
    if floor_key > len(stair_climbing_map[map_key][FLOORS]):
        raise BadRequestError('Invalid floor key')

    user_floor_data_ref = root_ref.child(DB_BETA_USER_FLOOR_DATA).child(user_id)
    user_floor_data = user_floor_data_ref.get() or {FLOOR_KEY: 0, MAP_KEY: TUTORIAL_MAP}

    current_user_floor_data = {FLOOR_KEY: user_floor_data[FLOOR_KEY], MAP_KEY: user_floor_data[MAP_KEY]}
    prev_floor_data = (
        {FLOOR_KEY: floor_key - 1, MAP_KEY: map_key} if floor_key else stair_climbing_map[map_key][PREV_FLOOR]
    )

    if current_user_floor_data != prev_floor_data:
        raise BadRequestError('Previous floor data mismatch')

    next_floor_info = {
        MAP_KEY: map_key,
        FLOOR_KEY: floor_key,
        ANIMATION_PLAYED_UP: False,
        UPDATED_TIME_UTC: handler.timestamp,
        LAST_ACTIVITY_DATA: None,
        ANIMATION_PLAYED_DOWN: None,
    }

    # Update user floor data
    user_floor_data_ref.update(next_floor_info)

    # Update user data change log
    root_ref.child(DB_BETA_USER_DATA_CHANGE_LOG).child(user_id).push().set(
        create_change_log_data_set(ref_key=FLOORS, new_data=next_floor_info)
    )

    return handler.response('', 201)
