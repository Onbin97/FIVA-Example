import firebase_admin as admin
from firebase_admin import credentials
from firebase_admin import db

# 어드민 계정 정보를 이용해 firebase-admin을 초기화
if "cred" not in dir():
    prod = False

    cred = credentials.Certificate('chalicelib/db/fiva_firebase_admin.json')
    admin.initialize_app(cred, {
        "databaseURL": "https://fiva-auth-%s-rtdb.firebaseio.com" % ("default" if prod else "develop")
    })
    ref = db.reference()
